(function(){
// ---- nav scroll compact ----
  var header = document.getElementById('siteHeader');
  window.addEventListener('scroll', function(){
    if(window.scrollY > 20){ header.classList.add('scrolled'); }
    else{ header.classList.remove('scrolled'); }
  });

  // ---- mobile menu ----
  var burger = document.getElementById('burgerBtn');
  var mobileMenu = document.getElementById('mobileMenu');
  var mobileClose = document.getElementById('mobileClose');
  burger.addEventListener('click', function(){ mobileMenu.classList.add('open'); });
  mobileClose.addEventListener('click', function(){ mobileMenu.classList.remove('open'); });
  document.querySelectorAll('.js-close-menu').forEach(function(el){
    el.addEventListener('click', function(){ mobileMenu.classList.remove('open'); });
  });

  // ---- reveal on scroll ----
  var reveals = document.querySelectorAll('.reveal');
  var io = new IntersectionObserver(function(entries){
    entries.forEach(function(e){
      if(e.isIntersecting){ e.target.classList.add('in'); io.unobserve(e.target); }
    });
  }, {threshold:0.12});
  reveals.forEach(function(el){ io.observe(el); });

  // ---- carousel ----
  var track = document.getElementById('carouselTrack');
  var slides = track.querySelectorAll('.slide');
  var dotsWrap = document.getElementById('carDots');
  var idx = 0;
  slides.forEach(function(_, i){
    var d = document.createElement('button');
    d.className = 'car-dot' + (i===0 ? ' active' : '');
    d.addEventListener('click', function(){ goTo(i); });
    dotsWrap.appendChild(d);
  });
  var dots = dotsWrap.querySelectorAll('.car-dot');
  function goTo(i){
    idx = (i + slides.length) % slides.length;
    track.style.transform = 'translateX(' + (-idx*100) + '%)';
    dots.forEach(function(d,j){ d.classList.toggle('active', j===idx); });
  }
  document.getElementById('carPrev').addEventListener('click', function(){ goTo(idx-1); });
  document.getElementById('carNext').addEventListener('click', function(){ goTo(idx+1); });

  // swipe support
  var startX = null;
  track.addEventListener('touchstart', function(e){ startX = e.touches[0].clientX; }, {passive:true});
  track.addEventListener('touchend', function(e){
    if(startX===null) return;
    var dx = e.changedTouches[0].clientX - startX;
    if(Math.abs(dx) > 40){ dx < 0 ? goTo(idx+1) : goTo(idx-1); }
    startX = null;
  }, {passive:true});

  // auto-advance, pauses on interaction
  var autoTimer = setInterval(function(){ goTo(idx+1); }, 6000);
  [track, dotsWrap].forEach(function(el){
    el.addEventListener('pointerdown', function(){ clearInterval(autoTimer); });
  });

  // ---- FAQ accordion ----
  document.querySelectorAll('.faq-item').forEach(function(item){
    var q = item.querySelector('.faq-q');
    var a = item.querySelector('.faq-a');
    q.addEventListener('click', function(){
      var isOpen = item.classList.contains('open');
      document.querySelectorAll('.faq-item.open').forEach(function(o){
        o.classList.remove('open');
        o.querySelector('.faq-a').style.maxHeight = null;
      });
      if(!isOpen){
        item.classList.add('open');
        a.style.maxHeight = a.scrollHeight + 'px';
      }
    });
  });

  // ---- modal ----
  var overlay = document.getElementById('modalOverlay');
  var modalClose = document.getElementById('modalClose');
  document.querySelectorAll('.js-open-modal').forEach(function(btn){
    btn.addEventListener('click', function(e){
      e.preventDefault();
      overlay.classList.add('open');
      document.body.style.overflow = 'hidden';
    });
  });
  function closeModal(){
    overlay.classList.remove('open');
    document.body.style.overflow = '';
  }
  modalClose.addEventListener('click', closeModal);
  overlay.addEventListener('click', function(e){ if(e.target === overlay) closeModal(); });

  // ---- form submit ----
  var form = document.getElementById('applyForm');
  var formMsg = document.getElementById('formMsg');
  var formView = document.getElementById('formView');
  var successView = document.getElementById('successView');
  var whatsappCta = document.getElementById('whatsappCta');

  // CONFIG: replace with the real destination WhatsApp number (country code, no + or spaces)
  var DESTINATION_WHATSAPP_NUMBER = '10000000000';
  // CONFIG: replace with the real destination email address
  var DESTINATION_EMAIL = 'apply@brightboxecom.com';

  form.addEventListener('submit', function(e){
    e.preventDefault();
    if(!form.checkValidity()){
      formMsg.style.display = 'block';
      form.reportValidity();
      return;
    }
    formMsg.style.display = 'none';

    var fd = new FormData(form);
    var data = {};
    fd.forEach(function(v,k){ data[k] = v; });

    var lines = [
      'NEW BRIGHTBOX ECOM APPLICATION',
      '',
      'Name: ' + data.fullName,
      'Email: ' + data.email,
      'WhatsApp: ' + data.whatsapp,
      'Country: ' + data.country,
      'Experience: ' + data.experience,
      'Owns a store: ' + data.ownsStore,
      'Monthly revenue: ' + (data.revenue || '-'),
      'Main goal: ' + data.goal,
      'Biggest challenge: ' + data.challenge,
      'Heard about us via: ' + data.source,
      'Notes: ' + (data.notes || '-')
    ];
    var message = lines.join('\n');

    // Prepare WhatsApp deep link with structured message
    whatsappCta.href = 'https://wa.me/' + DESTINATION_WHATSAPP_NUMBER + '?text=' + encodeURIComponent(message);

    // Prepare a mailto fallback so the applicant's browser can open a
    // pre-filled email to the configured destination. Note: for reliable,
    // silent server-side email delivery, wire this form to a backend or
    // form service (e.g. your own endpoint, Formspree, etc.) instead.
    try{
      var mailto = 'mailto:' + DESTINATION_EMAIL + '?subject=' + encodeURIComponent('New BRIGHTBOX ECOM Application - ' + data.fullName) + '&body=' + encodeURIComponent(message);
      var mailLink = document.createElement('a');
      mailLink.href = mailto;
      mailLink.style.display = 'none';
      document.body.appendChild(mailLink);
      // Not auto-clicked to avoid unexpected mail-client popups; left available if needed.
      document.body.removeChild(mailLink);
    }catch(err){}

    formView.style.display = 'none';
    successView.style.display = 'block';
  });
})();
