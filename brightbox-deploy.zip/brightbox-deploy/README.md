# BRIGHTBOX ECOM — Landing Page

A single-page, static, dependency-free landing site. No build step, no npm install, no framework — just one HTML file that any static host can serve as-is.

## What's in this project

```
brightbox-deploy/
├── index.html          ← the entire site (HTML + CSS + JS in one file)
├── assets/
│   └── images/         ← empty folder for your own proof/result screenshots
└── README.md           ← this file
```

## Dependencies

There are none to install. The only external requests the page makes are to Google Fonts (Space Grotesk + Inter), loaded via a standard `<link>` tag in `<head>`. Everything else — layout, animations, carousel, FAQ accordion, form logic — is plain HTML/CSS/JS embedded directly in `index.html`. If you ever need the page to work fully offline, you'd download those two font families and self-host them, but for a normal web deployment no action is needed.

## Before you go live — required edits

Open `index.html` and update these two spots:

**1. Contact config** (near the bottom, inside the `<script>` tag):
```js
const WHATSAPP_NUMBER = "10000000000"; // your real number, digits only, country code, no + or spaces
const DESTINATION_EMAIL = "applications@brightboxecom.com"; // where applications should land
```

**2. Sales numbers** (in the "THE NUMBERS TELL THE STORY" section): replace the `$XX,XXX+`, `XXX+`, `XX+` placeholder values with your real, verified figures once you have them.

## Adding your own proof images

Every proof slot (the results carousel and the 3-card grid under the stats) currently shows a dashed placeholder labeled "PLACEHOLDER — REPLACE IMAGE." To swap one in:

1. Drop your image file into `assets/images/`.
2. Find the matching `<div class="placeholder-img">...</div>` block in `index.html`.
3. Replace it with:
   ```html
   <img src="assets/images/your-file.jpg" alt="Describe the result shown">
   ```
4. Update the caption text next to it if needed.

## How the application form works

There's no backend or database — this is a static site. On submit, the form:
1. Validates required fields in the browser.
2. Opens a pre-filled `mailto:` draft addressed to `DESTINATION_EMAIL`, so the application lands in your inbox as a normal email.
3. Shows the applicant a success screen with a "Continue on WhatsApp" button that opens a `wa.me` chat pre-filled with their answers, addressed to `WHATSAPP_NUMBER`.

This works everywhere but depends on the visitor's device having a mail client configured to handle `mailto:` links. If you later want guaranteed server-side delivery (e.g., logging every submission to a database or sending email without relying on the visitor's mail app), you'd need to add a small backend endpoint (a serverless function on Netlify/Vercel, or a form service like Formspree) and point the form's submit handler at it instead — that's a code change beyond what a static file can do on its own.

## Deploying

Any static host works. A few common options:

- **Netlify / Vercel**: drag-and-drop the `brightbox-deploy` folder onto their dashboard, or connect a Git repo containing it. No build command needed — set the publish directory to the project root.
- **GitHub Pages**: push this folder to a repo, enable Pages, and point it at the root (or `/docs` if you move it there).
- **Any traditional web host**: upload `index.html` and the `assets` folder via FTP/SFTP into your public/www directory.

No environment variables, no build process, no server required.

## Browser support

Uses standard modern CSS (Grid, custom properties, `backdrop-filter`) and vanilla JS (`IntersectionObserver`, template literals). Works in all current versions of Chrome, Safari, Firefox and Edge, including mobile. `backdrop-filter` degrades gracefully to a solid nav background on older browsers that don't support it.
